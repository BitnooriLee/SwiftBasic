//: Playground - noun: a place where people can play

import UIKit

//mutable array
var emptyarray = Array<String>()
var emptyarray2 = [String]()

print(emptyarray.count)

emptyarray2.append("Olivia")
emptyarray2.append("YDJ")

print(emptyarray2)

var emptyarray3 = ["Olivia", "YDJ", "HJW"]
emptyarray3 += ["Andrew"]
emptyarray3 += ["Andrew"]
emptyarray3 += ["Andrew"]
emptyarray3 += ["Andrew"]
print(emptyarray3)
print(emptyarray3[3])


emptyarray3[2] = "Bitnoori"
print(emptyarray3)

emptyarray3[4...6] = ["A","B","C"]
print(emptyarray3)

//immutable array
let emptyarray4 = ["Olivia", "YDJ", "HJW"]

print(emptyarray4)
