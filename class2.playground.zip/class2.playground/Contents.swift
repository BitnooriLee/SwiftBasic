//: Playground - noun: a place where people can play

import UIKit

class Vehicle{
    var currentSpeed = 0.0 // stored property
    
    func makeNoise(){
        print("noiseless")
    }
}


let someVehicle = Vehicle()
print(someVehicle.currentSpeed)
someVehicle.currentSpeed = 1.0
print(someVehicle.currentSpeed)

someVehicle.makeNoise()

print("1")
