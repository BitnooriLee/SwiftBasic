//: Playground - noun: a place where people can play

import UIKit

//type inference
var str = "Hello, playground"
var version = 1.0
let year = 2018
let pretty = true


//type anotation
var str2:String = "Hello, playground"
var version2:Double = 1.0
let year2:Int = 2018
let pretty2:Bool = true

print("str: \(type(of: str))")
print(str)

print("version: \(type(of: version))")
print(version)

print("year: \(type(of: year))")
print(year)

print("pretty: \(type(of: pretty))")
print(pretty)
