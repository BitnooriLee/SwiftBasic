//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground. \nNice to meet you \n\"I am novice at swift\""

print(str)
print("==========")
var str2 = """
Hello, playground.
Nice to meet you
"I am novice at swift
"""

print(str2)

var emptyString = ""
var anotherEmptyString = String()

if emptyString.isEmpty {
    print("Nothing to see here")
}

let string1 = "hello"
let string2 = " there"

var welcome = string1 + string2
print(welcome)

var instruction = "look over"
instruction += string2

print(instruction)
print(instruction.count)
