//: Playground - noun: a place where people can play

import UIKit

let age = 7

if age < 3 {
    print("Baby")
}else if age>=3 && age < 20 {
    print("child")
}else {
    print("Adult")
}

switch age{
case 0,1,2:
    print("baby")
case 3...10:
    print("baby")
default:
    print("Adult")
}
